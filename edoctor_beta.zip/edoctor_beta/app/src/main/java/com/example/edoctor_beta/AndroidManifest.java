package com.example.edoctor_beta;

public class AndroidManifest {
}
