package com.example.edoctor_beta.ui.phone;

import android.os.Bundle;
import android.app.Activity;

import com.example.edoctor_beta.R;
//import com.example.edoctor_beta.R;

public class SecondActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6 );
    }
}
